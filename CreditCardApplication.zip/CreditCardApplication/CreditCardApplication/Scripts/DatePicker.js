﻿/* Date picker control */
$(function () {
  
    $('.datetimepicker').datepicker(
        {
            dateFormat: 'dd/mm/yyyy',
            maxDate: new Date,
            minDate: new Date(1900, 1, 1)
            
        });
})

$('.datetimepicker').datepicker({
    onSelect: function () {
        $('#data').text(this.value);
    }
});



$("#clearText").click(function () {
    $(this).closest('form').find("input[type=text], textarea").val("");
});

