﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CreditCardApplication.ViewModels;
using CreditCardApplication.ServiceLayer;

namespace CreditCardApplication.Controllers
{
   
    public class RegisterController : Controller
    {
        private const string V = "FirstName,LastName,DateOfBirth,AnnualIncome";
        ICustomerService cs;
        public RegisterController(CustomerService cs)
        {
            this.cs = cs;
        }

        public ActionResult Home()
        {
            CustomerViewModel cvm = new CustomerViewModel();
            return View(cvm);        

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Home([Bind(Include = V)] CustomerViewModel cvm)
        {
            try
            {
                cvm.CardType = String.Empty;

                if (ModelState.IsValid)
                {
                    var today = DateTime.Today;
                    int age = GetAge(cvm.DateOfBirth, today);

                    if (age < 18)
                    {
                        cvm.CardType = "Invalid User";
                        this.cs.InsertCustomerDetails(cvm);
                        return View("InvalidUser");

                    }
                    else if (age >= 18 && cvm.AnnualIncome >= 35000)
                    {

                        cvm.CardType = "BarClayCard";
                        this.cs.InsertCustomerDetails(cvm);
                        return View("BarClayCard");

                    }
                    else
                    {

                        cvm.CardType = "VanquisCard";
                        this.cs.InsertCustomerDetails(cvm);
                        return View("VanquisCard");

                    }
                }
                else
                {
                    return View(cvm);
                }
            }
            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Register", "Home"));
            }


        }
        public static int GetAge(DateTime dateOfBirth, DateTime dateAsAt)
        {
            return dateAsAt.Year - dateOfBirth.Year - (dateOfBirth.DayOfYear < dateAsAt.DayOfYear ? 0 : 1);
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            Exception exception = filterContext.Exception;
            //Logging the Exception
            filterContext.ExceptionHandled = true;


            var Result = this.View("Error", new HandleErrorInfo(exception,
                filterContext.RouteData.Values["controller"].ToString(),
                filterContext.RouteData.Values["action"].ToString()));

            filterContext.Result = Result;

        }
    }
}