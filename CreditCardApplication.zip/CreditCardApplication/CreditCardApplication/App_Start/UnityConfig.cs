using System.Web.Http;
using Unity;
using CreditCardApplication.ServiceLayer;
using Unity.WebApi;
using System.Web.Mvc;

namespace CreditCardApplication
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();
            container.RegisterType<ICustomerService, CustomerService>();
            DependencyResolver.SetResolver(new Unity.Mvc5.UnityDependencyResolver(container));      
            GlobalConfiguration.Configuration.DependencyResolver = new Unity.WebApi.UnityDependencyResolver(container);
        }
    }
}