﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace CreditCardApplication.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundle(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/bootstrap").Include("~/Scripts/jQuery-3.5.1.js", "~/Scripts/umd/popper.js", "~/Scripts/jquery.validate.min.js","~/Scripts/jquery.validate.unobtrusive.min.js","~/Scripts/bootstrap.js","~/Scripts/DatePicker.js"));
            bundles.Add(new StyleBundle("~/Styles/bootstrap").Include("~/Content/bootstrap.css"));
            bundles.Add(new StyleBundle("~/Styles/site").Include("~/Content/Styles.css"));
            BundleTable.EnableOptimizations = true;

        }
    }
}