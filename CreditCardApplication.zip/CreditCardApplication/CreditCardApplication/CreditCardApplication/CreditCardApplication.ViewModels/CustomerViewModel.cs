﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardApplication.ViewModels
{
   

    public class CustomerViewModel
    {
        [Required(ErrorMessage = "Please enter your first name.")]
        [DisplayName("First Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Please enter alphabets only.")]

        public string FirstName { get; set; }

        [Required(ErrorMessage ="Please enter your last name.")]
        [DisplayName("Last Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Please enter alphabets only.")]

        public string LastName { get; set; }

        [Required (ErrorMessage ="Please enter your date of birth.")]
        [DisplayName("Date Of Birth")]
        [DateLessThanFutureDate]
        [DataType(DataType.Date, ErrorMessage ="please enter a valid date for the date of birth"), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]

        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage ="Please enter your annual income. ")]
        [DisplayName("Annual Income (£)")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:#.#}")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter numbers only.")]
        public double AnnualIncome { get; set; }

        public string CardType { get; set; }

        public DateTime CreatedDate { get; set; }




    }
}
