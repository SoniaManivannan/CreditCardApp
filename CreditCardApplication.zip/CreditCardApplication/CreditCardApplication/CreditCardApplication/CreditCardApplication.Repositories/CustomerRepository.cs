﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using CreditCardApplication.DomainModels;

namespace CreditCardApplication.Repositories
{
    
    public interface ICustomerRepository
    {
        void InsertCustomerDetails(Customer c);
    }

    public class CustomerRepository : ICustomerRepository
    {
        CreditCardDatabaseDbContext db;
        public CustomerRepository()
        {
            db = new CreditCardDatabaseDbContext();
        }


        public void InsertCustomerDetails(Customer c)
        {
           
                c.CreatedDate = DateTime.Now;
                db.customers.Add(c);
                db.SaveChanges();
          
           
        }
    }
}
