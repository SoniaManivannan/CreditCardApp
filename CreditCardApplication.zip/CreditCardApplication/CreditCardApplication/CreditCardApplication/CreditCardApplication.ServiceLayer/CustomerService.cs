﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using CreditCardApplication.DomainModels;
using CreditCardApplication.ViewModels;
using CreditCardApplication.Repositories;
using AutoMapper;

namespace CreditCardApplication.ServiceLayer
{

    public interface ICustomerService
    {
        int InsertCustomerDetails(CustomerViewModel cvm);
    }


    public class CustomerService : ICustomerService
    {
        ICustomerRepository cr;
        
        public CustomerService()
        {
            cr = new CustomerRepository();
        }
        public int InsertCustomerDetails(CustomerViewModel cvm)
        {
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<CustomerViewModel, Customer>(); });
            IMapper mapper = config.CreateMapper();
            Customer c = mapper.Map<CustomerViewModel, Customer>(cvm);
            cr.InsertCustomerDetails(c);
            return 1;
        }
    }
}
